Black Rock Shooter blogger Template,adalah template Free untuk blogger.
dilarang memperjualkan template ini,tolong untuk tidak menghapus credit.
bijaklah menggunakan template gratis dan hargai kerja keras saya sebagai pembuat template ini.


thx sudah menggunakan template saya. ^^

Http://djogzs.blogspot.com

http://www.facebook.com/djogzs

#note:dilarang mengklaim/mengaku karya orang lain.